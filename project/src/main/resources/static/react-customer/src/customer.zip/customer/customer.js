import React from "react";
import {useState, useEffect} from "react"

function Sidebar(){
    return(
        <>
            <div className="menu">
                <nav>
                    <h2>거래처</h2>
                    <button type="button">신규 거래처 등록</button>
                    <h3>거래처</h3>
                    <ul>
                        <li><a href="#">매출</a></li>
                        <li><a href="#">매입</a></li>
                        <li><a href="#">기타</a></li>
                    </ul>
                    <h3>거래처 그룹</h3>
                    <ul>
                        <li>그룹1</li>
                        <li>그룹2</li>
                    </ul>
                    <h3>리포트</h3>
                    <h3>사용자 관리 기능</h3>
                    <button type="button" className="btnImport">import</button>
                    <button type="button" className="btnExport">export</button>
                </nav>
            </div>
        </>
    )
}

export default Sidebar