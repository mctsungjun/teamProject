import React from 'react'

function Contents(){
    return(
        <>
            <div className="contentsList">
                <ul className="contentHeader">
                    <li>No</li>
                    <li>거래처명</li>
                    <li>대표자명</li>
                    <li>담당자</li>
                    <li>연락처</li>
                    <li>주소</li>
                    <li>이메일</li>
                    <li>사업자번호</li>
                    <li>등록일</li>
                </ul>
                <div className="customerList">
                    <ul>
                        <li><a href='#'>거래처 목록 표시 해야하는 곳 더미 테스트</a></li>
                    </ul>
                </div>
                <div>
                    <ul>
                        <li><a href='#'>&#171;</a></li>
                        <li><a href='#'>1</a></li>
                        <li><a href='#'>2</a></li>
                        <li><a href='#'>3</a></li>
                        <li><a href='#'>4</a></li>
                        <li><a href='#'>5</a></li>
                        <li><a href='#'>6</a></li>
                        <li><a href='#'>7</a></li>
                        <li><a href='#'>8</a></li>
                        <li><a href='#'>9</a></li>
                        <li><a href='#'>&#187;</a></li>
                    </ul>
                    <button type='button'>수정</button>
                    <button type='button'>등록</button>
                </div>
            </div>
        </>
    )
}
export default Contents