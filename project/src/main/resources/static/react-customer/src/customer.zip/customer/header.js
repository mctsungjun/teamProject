import React from 'react';

function Header() {
  return(
    <>
        <div className='header'>
            <div>
                우측 상단 아이콘영역
            </div>
            <div>
                <span>미수금</span>
                <span>미지급금</span>
            </div>
            <div>
                <span>목록 갯수</span>
                <span>거래처 갯수</span>
            </div>
            
            <div>
                <input type='text' placeholder='검색어를 입력해주세요'/>
                <button type='button' className='btnSearch'>검색</button>
            </div>
        </div>
    </>
  )
  
}

export default Header;
